import Foundation

//Date Formatting

///The output format automatically adjusts according to the user’s locale. Each field just tells the formatter what values should be included somewhere in the final output.

let date = Date.now

///The order of the fields you provide does not matter.
let formatted = date.formatted(.dateTime.year().day().month())
let formattedOrderChanged = date.formatted(.dateTime.year().month().day())

/// Wide format means that the full month name is printed.
let formattedWide = date.formatted(.dateTime.year().day().month(.wide))
let formattedWeekDAy = date.formatted(.dateTime.weekday(.wide))

let logFormat = date.formatted(.iso8601)
let fileNameFormat = date.formatted(.iso8601.year().month().day().dateSeparator(.dash))

/// The .dateTime lets us specify custom locale
let dateEnLocale = date.formatted(.dateTime.locale(Locale(identifier: "en")))
let dateRuLocale = date.formatted(.dateTime.locale(Locale(identifier: "ru")))

//Intervals

let now = Date.now
let later = now + TimeInterval(5000)

let range = (now..<later).formatted()
let noDate = (now..<later).formatted(date: .omitted, time: .complete)
let timeDuration = (now..<later).formatted(.timeDuration)
let components = (now..<later).formatted(.components(style: .wide))
let relative = later.formatted(.relative(presentation: .named, unitsStyle: .wide))

//Parsing Dates

///  The strategy is used to tell the parser what fields to expect in the input.
let format = Date.FormatStyle().year().day().month()
let formattedDate = date.formatted(format)

let formatDate = try? Date(formatted, strategy: format)


/// Here, we parse a fixed format, which is useful when the date format is something received from a server.
/// To use it, initialize a strategy with a format string.
/// Instead of using magic string values, though, we use string interpolation.
let strategy = Date.ParseStrategy(
    format: "(\(year: .defaultDigits)-\(month: .twoDigits)-\(day: .twoDigits) )", timeZone: TimeZone.current)
var strategyDate = try? Date("2021-06-07", strategy: format)

//Formatting numbers

let value = 12345
let valueFormated = value.formatted()

let scientific = 42e9
let scientificFormated = scientific.formatted(.number.notation(.scientific))

let percent = 25
let percentFormatted = percent.formatted(.percent)

let price = 29
let priceFormatted = price.formatted(.currency(code: "eur"))


//Formatting lists

/// Member style argument specifies the format style of each element in the array.
let list = [25,50,75].formatted(.list(memberStyle: .percent, type: .or))

let colours = ["red", "green", "blue"].formatted()
let colorsList = ["red", "green", "blue"].formatted(.list(type: .or))


//ByteCountFormatter

let y = 38436483.formatted(.byteCount(style: .file, allowedUnits: .all, spellsOutZero: true, includesActualByteCount: false))


//Measurement

let length = Measurement(value: 1230, unit: UnitLength.meters)
let lengthFormatted = length.formatted()
let lengthFormattedWidth = length.formatted(.measurement(width: .narrow))

let temperature = Measurement(value: 24, unit: UnitTemperature.celsius)
let formatter  = MeasurementFormatter()

let temperatureFormatter = formatter.string(from: temperature)

formatter.locale = Locale(identifier: "eu-En")
formatter.string(from: temperature)

formatter.unitOptions = .temperatureWithoutUnit
formatter.string(from: temperature)

//: ## Unit Options
let run = Measurement(value: 20000, unit: UnitLength.meters)
formatter.unitOptions = .providedUnit
formatter.string(from: run)
formatter.unitOptions = .naturalScale
formatter.string(from: run)

//: ## Unit Style
formatter.unitStyle = .long
formatter.string(from: run)

//PersonNameComponents

let person = PersonNameComponents(namePrefix: "Sir", givenName: "Arthur", middleName: "Conan", familyName: "Doyle")
let personFormatted = person.formatted()                 
let personFormattedWithLongStyle = person.formatted(.name(style: .long))
